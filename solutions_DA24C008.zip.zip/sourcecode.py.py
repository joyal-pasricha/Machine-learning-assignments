#importing libraries 
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 

#making a function to load the datasets-here training data(1000 rows) and testing data(100 rows)
def load_datasetfiles(filename):
    """here the files are in csv format.
    the function does the following-
    input-a variable storing the path of the csv file containing data
    output-returns feature matrix X and associated target variable y as a tuple"""
    data=np.loadtxt(filename,delimiter=',') 
    #loadtxt reads data from csv file, delimiter-separates data  values using ","
    
    #value extraction
    X=data[:,:2]#takes values from all rows but from first 2 columns and stores in X(which consists of 2 feature values now )
    y=data[:,2] #takes values from all rows but from 3rd column(target variable)
    return X,y

#laoding datasets
X_train,y_train=load_datasetfiles("C:\\Users\\Joyal Pasricha\\Downloads\\FMLASSIGNMENT1\\FMLA1Q1Data_train.csv")
print(X_train, y_train)
X_test,y_test=load_datasetfiles("C:\\Users\\Joyal Pasricha\\Downloads\\FMLASSIGNMENT1\\FMLA1Q1Data_test.csv")
print(X_test, y_test)

#introducing a bias term to X(for features) in both train and test data
X_train_bias=np.c_[np.ones(X_train.shape[0]), X_train] 
#np.ones creates 1D array of 1s with 1000 rows 
##np.c_ creates/adds a column of 1s to the left of X_train to make X_train_bias
X_test_bias=np.c_[np.ones(X_test.shape[0]), X_test] #does the same as above for X_test
print(X_train_bias)
print(X_test_bias)

#PURPOSE OF ADDING A BIAS TERM-
#1.Doing this allows the regression line to have a non zero intercept and adjusts for any vertical shift.
#2.Without the bias tem, it is assumed that the line passes through (0,0), which may lead to inaccuracies.
#3.the data has no bias, the coefficient will be 0, otherwise not.

#TASK 1-. Write a piece of code to obtain the least squares solution wML to the regression problem using the analytical solution.
#TASK1-least squares solution w_ml
def least_squares_solution(X,y):
    """input: x-feature matrix with bias term,y-target variable
    output-optimal least squaressolution/parameter(or weight) vector"""
    return np.linalg.inv(X.T@X)@X.T@y #T-transpose,@-multiplication
#used the least squares solution formula
w_ml=least_squares_solution(X_train_bias,y_train)
print(w_ml)

#TASK2-Code the gradient descent algorithm with suitable step size to solve the leastsquares algorithms and plot ∥wt − wML∥2 as a function of t. What do you observe?
#TASK2CODE-GD ALOGORITHM
#function for making gradient descent(GD)
def gradient_descent_algo(X,y,step_size,numberof_iterations):
    """functions does the following-
    input:X-input data(feature matrix)
    y-output data(target variable)
    step_size-learning rate or size of steps taken to reach the minima
    numberof_iterations-to update the weights"""
    m_X,n_X=X.shape #it gives dimensions of X(m=rows/no of samples,n=cols/no. of features)
    w=np.zeros(n_X) #intialises weight vector as 0s of dim n
    w_history=[w] #list that keeps track of w after each iteration
    
    for _ in range(numberof_iterations):
        gradient=(2/m_X)*X.T@(X@w-y)
        #(X@w-y) is the diff b/w predicted and actual values
        #X.T@(X@w-y): gives gradient
        #(2/m):to normalise the gradient
        w=w-(step_size*gradient) #updated weights
        w_history.append(w)
    return np.array(w_history) #list containing weights' history thru all iterations
    
#using the GDALGO function
step_size=0.01
numberof_iterations=1000
gd_w_history=gradient_descent_algo(X_train_bias,y_train,step_size,numberof_iterations)
print(gd_w_history)

#plotting gradient descent convergence on graph
plt.figure(figsize=(10,5))
plt.plot(np.linalg.norm(gd_w_history-w_ml,axis=1)) #L2 norm
plt.ylabel("||w^t-w_ml||_2")
plt.xlabel("iterations")
plt.title("gradient descent convergence plot")
plt.show()


"""OBSERVATIONS FROM TASK 2-
The graph shows convergence of the GD algorithm for the least squares solution where iterations are on x axis and L2 norm of weight diff is on y axis.
It is observed that there is quick convergence in approximately first 200 iterations which is followed by gradual decrease in error as the algorithm approaches the optimal weights.
So the algorithm shows convergence without oscillation and effectively solves the given problem of least squartes."""

#TASK3-Code the stochastic gradient descent algorithm using batch size of 100 and plot ∥wt − wML∥2 as a function of t. What are your observations?
#TASK3-STOCHASTIC GRADIENT DESCENT
#function for sgd(stochastic gradient descent)
def sgd_algo(X,y,batch_size,step_size,numberof_iterations):
    """implements sgd and does the following-
    input:
    X:input data ,y-output data,batch_size-no of samples per batch to use for updating weights,step_size,
    numberof_iterations
    output:
    returns a list of weight vectors"""
    m_X,n_X=X.shape 
    w=np.zeros(n_X)
    w_history=[w] #for tracking of weights
    for _ in range(numberof_iterations):
        indices=np.random.choice(m_X,batch_size,replace=False) 
        #selects batches randomly w/o replacement from total no(10000) of samples m, 
        #so per teration only 1 sample is selected 
        X_batch=X[indices] #extraction of feature data acc to selected indices
        y_batch=y[indices] #extraction of target variable data acc to selected indices
        sgradient=(2/batch_size)*X_batch.T@((X_batch@w)-y_batch) #formula for sgd calculation
        w=w-step_size*sgradient
        w_history.append(w)
    return np.array(w_history)
#using the sgd function
batch_size=100 #given in ques
numberof_iterations=1000
step_size=0.01
sgd_w_history=sgd_algo(X_train_bias,y_train,batch_size,step_size,numberof_iterations)
print(sgd_w_history)

#plotting sgd on graph
plt.figure(figsize=(10,5))
plt.plot(np.linalg.norm(sgd_w_history-w_ml,axis=1))
plt.ylabel("||w^t-x_ml||_2")
plt.xlabel("iterations")
plt.title("STOCHASTIC GRADIENT DESCENT GRAPH SHOWING CONVERGENCE")
plt.show()

"""OBSERVATIONS FROM TASK 3 SGD GRAPH-
The graph shows convergence overall. The decreasing trend indicates convergence to a stable solution.
SGD fluctuates in comparison to the standard GD because we are choosing random batches in each iteration 
instead of choosing the whole dataset in one go(like we do in stndard GD). But overall the trend is downwards
so a stable solution is possible."""

#TASK 4-Code the gradient descent algorithm for ridge regression. Cross-validate for various choices of λ and plot the error in the validation set as a function of λ. For the best λ chosen, obtain wR. Compare the test error (for the test data in the file FMLA1Q1Data test.csv) of wR with wML. Which is better and why?
#TASK4-RIDGE REGRESSION
def ridge_regression(X,y,lambda_para):
    """function computes the ridge regression weights which help in to minimize the 
    loss function with L2 regularization and here lambda_para-regularization parameter which controls shrinkage"""
    return np.linalg.inv(X.T@X+lambda_para*np.eye(X.shape[1]))@X.T@y
#para*np.eye(X.shape[1]) term creates a diagonla maytrix scaled by lambda with dim=no. of features(2 here)

def cross_validation(X,y,lambdas,k=5):
    """lambdas=list of reg parameters,k=no of folds"""
    m_X=X.shape[0] #no of samples(here 1000)
    fold_size=m_X//k #size of each fold for cross validation
    errors=[] #will store the avg errors for each lambda
    for lambda_para in lambdas:
        crossval_errors=[] #stores cross validation errors for the CURRENT lambda
        for i in range(k): #k fold cross validation
            start=i*fold_size #starting index for current fold
            end=start+fold_size #ending index for curent fold
            X_val=X[start:end]
            y_val=y[start:end] #extracting validation data from current fold
            X_train=np.concatenate([X[:start],X[end:]])
            y_train=np.concatenate([y[:start],y[end:]])
            w=ridge_regression(X_train,y_train,lambda_para)
            error=np.mean((X_val@w-y_val)**2)
            crossval_errors.append(error)
        errors.append(np.mean(crossval_errors))
    return errors

#using the functions
lambdas=np.logspace(-5,5,50)
crossval_errors=cross_validation(X_train_bias,y_train,lambdas)
print(crossval_errors)

#PLOTTING ERROS IN  VALIDATION SET AS FUNCTION OF LAMBDA
plt.figure(figsize=(10,5))
plt.semilogx(lambdas,crossval_errors)
plt.xlabel('lambda')
plt.ylabel('Validation Error')
plt.title('Ridge Regression Cross-Validation')
plt.show()

#choosing the best lambda
best_lambda=lambdas[np.argmin(crossval_errors)]
print("best lambda is",best_lambda)
w_R=ridge_regression(X_train_bias,y_train,best_lambda)
print(" w for ridge regression is",w_R)
#Comparing test errors
mse_ML=np.mean((X_test_bias@w_ml-y_test)**2)
mse_R=np.mean((X_test_bias@w_R-y_test)**2)

print("Test MSE (Least Squares):",mse_ML)
print("Test MSE (Ridge Regression)",mse_R)

"""OBSERVATIONS FOR TASK4-
Ridge Regression yields a slightly lower MSE and this indicates slight;ly better performance. 
Ridge Regression reduces overfitting by penalizing weight magnitudes and improves generalization to unseen data.
While Least Squares minimizes training error, it may not generalize well. The chosen best lambda reflects
moderate regularization, balancing training error and model complexity. 
Overall, Ridge Regression shows slight improvement in test error, 
with more significant benefits expected in complex scenarios, SO w_R is better than w_ml."""

#TASK5-Assume that you would like to perform kernel regression on this dataset. Which Kernel would you choose and why? Code the Kernel regression algorithm and predict for the test data. Argue why/why not the kernel you have chosen is a better kernel than the standard least squares regression.
#TASK5: Kernel Regression-M
def polynomial_kernel(X1, X2, degree=2):
    return (X1 @ X2.T + 1) ** degree

def kernel_regression(X, y, kernel):
    K = kernel(X, X)
    alpha = np.linalg.pinv(K) @ y
    return alpha

def predict_kernel_regression(X_test, X_train, alpha, kernel):
    K_test = kernel(X_test, X_train)
    y_pred = K_test @ alpha
    return y_pred
# Fit kernel regression on the training data
alpha = kernel_regression(X_train_bias, y_train, polynomial_kernel)
# Predict on the test data
y_pred_kernel = predict_kernel_regression(X_test_bias, X_train_bias, alpha, polynomial_kernel)
# Calculate Mean Squared Error for the predictions
mse_kernel = np.mean((y_pred_kernel - y_test) ** 2)
# Output the results
print(f"Alpha coefficients: {alpha}")
print(f"Test MSE (Kernel Regression): {mse_kernel}")

"""Conclusions from Kernel Regression- 
Kernel regression can model non-linear relationships better than standard least squares.
It weighs nearby points more heavily,giving a better fit.
This flexibility allows kernel regression to adapt to varying data distributions."""





